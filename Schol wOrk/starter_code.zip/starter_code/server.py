# Server to implement a simple program to receive two prime numbers from a
# client. The server will compute their product and send it back to the client.
# If the server-calculated product matches what the client computes, the client
# will send a 200 OK status code to the server. Otherwise a 400 Error code is
# sent to the server.

# Author: fokumdt
# Last modified: 2022-10-08
#!/usr/bin/python3

import socket
import sys

def clientHello():
  """Generates client hello message"""
  msg = "105 Hello"
  return msg

def firstPrimeAck():
  """Acknowledges the first prime number"""
  msg = "111 Prime Ack"
  return msg

def secondPrimeAck(state):
  """Acknowledges the second prime number"""
  pass

#s      = socket
#msg    = message being processed
#state  = dictionary containing state variables
def processMsgs(s, msg, state):
  """This function processes messages that are read through the socket. It returns
     a status, which is an integer indicating whether the operation was successful."""
  pass

def main():
  """Driver function for the server."""
  args = sys.argv
  if len(args) != 2:
    print ("Please supply a server port.")
    sys.exit()
  HOST = ''              #Symbolic name meaning all available interfaces
  PORT = int(args[1])    #The port on which the server is listening.
  if (PORT < 1023 or PORT > 65535):
    print("Invalid port specified.")
    sys.exit()

  print("Server of _____")
  with socket.socket('''specify socket parameters to use TCP''') as s:
    # Bind socket
    # listen
    conn, addr = # accept connections using socket
    with conn:
      print("Connected from: ", addr)
      #Process messages received from socket using 
      #  processMsgs(s, msg, state)
      
if __name__ == "__main__":
    main()